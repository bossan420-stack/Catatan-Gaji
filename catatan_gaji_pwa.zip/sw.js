const CACHE="catatan-gaji-v1";
const ASSETS=["./","./index.html","./manifest.json","./sw.js","./icon-192.png","./icon-512.png","./icon-180.png"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS))));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
